import { Link } from "react-router";
import { NOMBRE_COMANDO_WEB } from "../nombres.ts";
import { pedir } from "../api.ts";
import { fechaHora } from "../formato.ts";
import { useEsAdmin, useFormulario, useLectura } from "../ganchos.ts";
import type {
  Conflicto,
  ListaMovimientos,
  ResumenInventario,
  StockPorTipo,
  UsuarioEnLista,
} from "../tipos.ts";
import {
  Aviso,
  BotonEnlace,
  Boton,
  Lectura,
  Seccion,
  Vacio,
} from "../ui/componentes.tsx";
import { Pagina } from "../ui/componentes.tsx";
import {
  ListaGuias,
  ListaZonas,
  RepartoEquipos,
  TablaPorTipo,
} from "../ui/Tablero.tsx";

export function Inicio() {
  const resumen = useLectura<ResumenInventario>("/inventario/resumen");
  const stock = useLectura<StockPorTipo>("/inventario/stock-por-tipo");
  const guias = useLectura<ListaMovimientos>("/movimientos?porPagina=6");
  const zonas = useLectura<{ datos: { zona: string; equipos: number }[] }>(
    "/zonas",
  );
  const esAdmin = useEsAdmin();

  return (
    <Pagina
      titulo="Dónde están los equipos"
      descripcion="Todos los equipos con serial según su estado, y lo último que salió o entró de las bodegas."
      acciones={
        <>
          <BotonEnlace a="/equipos/nuevo" icono="mas">
            Ingresar equipo
          </BotonEnlace>
          <BotonEnlace a="/guias/nueva/DESPACHO" variante="secundario">
            Despachar a proyecto
          </BotonEnlace>
        </>
      }
    >
      <Lectura estado={resumen}>
        {(r) =>
          r.total === 0 ? (
            <Vacio
              titulo="Todavía no hay equipos registrados."
              accion={
                <BotonEnlace a="/equipos/nuevo">
                  Ingresar el primer equipo
                </BotonEnlace>
              }
            >
              Cree una bodega y un proyecto, y luego registre el ingreso de los
              equipos que llegan del proveedor.
            </Vacio>
          ) : (
            <RepartoEquipos r={r} />
          )
        }
      </Lectura>

      {esAdmin ? <PendientesAdmin /> : null}

      <div className="columnas">
        <Seccion titulo="Equipos por tipo">
          <Lectura estado={stock}>
            {(s) => <TablaPorTipo datos={s.datos} />}
          </Lectura>
          <p className="suave nota-stock">
            <b>En stock</b> son los equipos disponibles para instalar. Los del
            inventario histórico ya están entregados a sus usuarios, por eso
            cuentan como instalados.
          </p>
        </Seccion>

        <div>
          {zonas.datos && zonas.datos.datos.length > 0 ? (
            <Seccion titulo="Equipos por zona">
              <ListaZonas datos={zonas.datos.datos} />
            </Seccion>
          ) : null}

          <Seccion
            titulo="Últimas guías"
            accion={<Link to="/guias">Ver todas</Link>}
          >
            <Lectura estado={guias}>{(g) => <ListaGuias guias={g} />}</Lectura>
          </Seccion>
        </div>
      </div>
    </Pagina>
  );
}

/** Cuentas por autorizar y operaciones sin conexión que el servidor rechazó (RNF-01). */
function PendientesAdmin() {
  const cuentas = useLectura<UsuarioEnLista[]>("/usuarios");
  const conflictos = useLectura<{ datos: Conflicto[] }>("/sync/conflictos");
  const f = useFormulario();
  const porAutorizar = cuentas.datos?.filter((u) => u.pendiente).length ?? 0;
  const lista = conflictos.datos?.datos ?? [];
  if (porAutorizar === 0 && lista.length === 0) return null;

  const resolver = async (id: string) => {
    const r = await f.ejecutar(() =>
      pedir("POST", `/sync/conflictos/${id}/resolver`),
    );
    if (r) conflictos.recargar();
  };

  return (
    <Seccion titulo="Para revisar">
      <div className="formulario">
        {porAutorizar > 0 ? (
          <Aviso tipo="atencion">
            {porAutorizar === 1
              ? "Hay 1 cuenta nueva"
              : `Hay ${porAutorizar} cuentas nuevas`}{" "}
            esperando autorización. <Link to="/cuentas">Revisar cuentas</Link>
          </Aviso>
        ) : null}
        {f.mensaje ? <Aviso tipo="error">{f.mensaje}</Aviso> : null}
        {lista.length > 0 ? (
          <div className="tabla-envoltura">
            <table className="tabla">
              <caption className="visualmente-oculto">
                Operaciones hechas sin conexión que el servidor rechazó
              </caption>
              <thead>
                <tr>
                  <th>Operación rechazada al sincronizar</th>
                  <th>Motivo</th>
                  <th>Quién</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {lista.map((c) => (
                  <tr key={c.id}>
                    <td>
                      {NOMBRE_COMANDO_WEB[
                        c.tipo as keyof typeof NOMBRE_COMANDO_WEB
                      ] ?? c.tipo}
                      <span className="secundaria">
                        Hecha el {fechaHora(c.ocurridoEn)}
                      </span>
                    </td>
                    <td>{c.error.mensaje}</td>
                    <td>{c.autor ?? c.dispositivoId ?? "—"}</td>
                    <td className="derecha">
                      <Boton
                        variante="secundario"
                        pequeno
                        onClick={() => void resolver(c.id)}
                      >
                        Marcar revisada
                      </Boton>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </div>
    </Seccion>
  );
}
